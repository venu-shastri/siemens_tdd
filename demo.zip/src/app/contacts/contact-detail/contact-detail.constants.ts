export const constants = {
  NO_CONTACT_FOUND_MESSAGE: 'Contact not found',
  LOADING_CONTACT_MESSAGE: 'Loading contact...'
};
