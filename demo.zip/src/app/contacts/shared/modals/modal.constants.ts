export const constants = {
  INVALID_PHONE_NUMBER_MESSAGE: 'Please enter a phone number with 10 digits (For example, 2125551234).',
  INVALID_EMAIL_ADDRESS_MESSAGE: 'Please enter a valid email address.'
};
