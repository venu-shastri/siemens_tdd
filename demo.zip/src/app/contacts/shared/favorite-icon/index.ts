export * from './favorite-icon.directive';
