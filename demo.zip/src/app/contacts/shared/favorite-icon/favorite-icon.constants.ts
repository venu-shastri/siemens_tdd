export const constants = {
  classes: {
    SOLID_STAR: 'fa fa-star fa-lg',
    OUTLINE_STAR: 'fa fa-star-o fa-lg',
    SOLID_STAR_STYLE_LIST: ['fa', 'fa-star', 'fa-lg'],
    OUTLINE_STAR_STYLE_LIST: ['fa', 'fa-star-o', 'fa-lg']
  }
};
