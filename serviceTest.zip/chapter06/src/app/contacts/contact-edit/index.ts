export * from './contact-edit.component';
