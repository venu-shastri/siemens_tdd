export * from './contact-detail.component';
