export * from './phone-number.pipe';
