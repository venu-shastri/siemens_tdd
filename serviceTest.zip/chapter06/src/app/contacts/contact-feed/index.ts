export * from './contact-feed.component';
