export const constants = {
  NO_CONTACTS_FOUND_MESSAGE: 'You do not have any contacts yet',
  LOADING_CONTACTS_MESSAGE: 'Loading contacts...',
  DELETING_CONTACTS_MESSAGE: 'Deleting contacts...',
  DELETING_CONTACT_MESSAGE: 'Deleting contact...',
};
