describe('tests', () => {
  it('Our first Jasmine test', () => {
		expect(true).toBe(true);
	});

	it('2 + 2 equals 4', () => {
		expect(2 + 2).toBe(4);
	});
});

